# Myriad_Modpack
WIP Modpack focused around lots of building, new encounters, and a balanced approach to enchanted equipment
